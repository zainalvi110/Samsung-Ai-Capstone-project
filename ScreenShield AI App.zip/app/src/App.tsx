import { useState, useEffect } from 'react'
import './App.css'
import { 
  Home, 
  Heart, 
  Smartphone, 
  BookOpen, 
  Sparkles,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  ChevronRight,
  Moon,
  Sun,
  Wind,
  Music,
  Coffee,
  Activity
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { toast } from 'sonner'

// Types
type Tab = 'home' | 'mood' | 'screen' | 'stress' | 'suggestions'
type Mood = 'great' | 'good' | 'okay' | 'bad' | 'terrible'

interface DailyData {
  mood: Mood | null
  screenTime: number
  stressLevel: number
  lastUpdated: Date
}

// Mood configurations
const moodConfig: Record<Mood, { emoji: string; label: string; color: string }> = {
  great: { emoji: '🤩', label: 'Great', color: 'bg-green-500' },
  good: { emoji: '😊', label: 'Good', color: 'bg-emerald-400' },
  okay: { emoji: '😐', label: 'Okay', color: 'bg-yellow-400' },
  bad: { emoji: '😔', label: 'Bad', color: 'bg-orange-400' },
  terrible: { emoji: '😫', label: 'Terrible', color: 'bg-red-400' }
}

// Coping suggestions based on mood and stress
const copingSuggestions: Record<string, { icon: any; title: string; desc: string; duration: string }[]> = {
  highStress: [
    { icon: Wind, title: 'Deep Breathing', desc: 'Take 5 deep breaths. Inhale for 4 counts, hold for 4, exhale for 6.', duration: '2 min' },
    { icon: Music, title: 'Calming Music', desc: 'Listen to soft instrumental or nature sounds to relax your mind.', duration: '10 min' },
    { icon: Coffee, title: 'Tea Break', desc: 'Have a warm cup of chai. Green tea or chamomile helps reduce stress.', duration: '5 min' },
    { icon: Moon, title: 'Power Nap', desc: 'A 20-minute nap can refresh your mind and reduce stress hormones.', duration: '20 min' }
  ],
  screenFatigue: [
    { icon: Sun, title: '20-20-20 Rule', desc: 'Every 20 minutes, look at something 20 feet away for 20 seconds.', duration: 'Ongoing' },
    { icon: Activity, title: 'Eye Exercises', desc: 'Roll your eyes clockwise and counterclockwise. Blink frequently.', duration: '2 min' },
    { icon: Wind, title: 'Walk Outside', desc: 'Step outside for fresh air. Natural light helps reset your circadian rhythm.', duration: '10 min' },
    { icon: Heart, title: 'Stretch Break', desc: 'Stretch your neck, shoulders, and back to release tension.', duration: '5 min' }
  ],
  academic: [
    { icon: BookOpen, title: 'Pomodoro Technique', desc: 'Study for 25 minutes, then take a 5-minute break. Repeat 4 times.', duration: '2 hours' },
    { icon: CheckCircle2, title: 'Task Prioritization', desc: 'List your tasks by importance. Focus on one at a time.', duration: '5 min' },
    { icon: Sparkles, title: 'Mindful Study', desc: 'Find a quiet space. Put phone on silent. Focus fully on one subject.', duration: 'Varies' },
    { icon: Coffee, title: 'Study Snacks', desc: 'Eat brain foods: nuts, fruits, dark chocolate. Stay hydrated.', duration: 'Ongoing' }
  ]
}

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('home')
  const [dailyData, setDailyData] = useState<DailyData>({
    mood: null,
    screenTime: 4.5,
    stressLevel: 6,
    lastUpdated: new Date()
  })
  const [burnoutRisk, setBurnoutRisk] = useState<number>(45)
  const [streak] = useState(7)

  // Calculate burnout risk based on data
  useEffect(() => {
    const moodScore = dailyData.mood ? 
      { great: 10, good: 8, okay: 5, bad: 3, terrible: 1 }[dailyData.mood] : 5
    const screenScore = Math.max(0, 10 - dailyData.screenTime)
    const stressScore = 10 - dailyData.stressLevel
    const risk = Math.round(100 - ((moodScore + screenScore + stressScore) / 3) * 10)
    setBurnoutRisk(Math.min(100, Math.max(0, risk)))
  }, [dailyData])

  const handleMoodSelect = (mood: Mood) => {
    setDailyData(prev => ({ ...prev, mood, lastUpdated: new Date() }))
    toast.success(`Mood recorded: ${moodConfig[mood].label}`, {
      description: 'Keep tracking to get better insights!'
    })
  }

  const getBurnoutMessage = () => {
    if (burnoutRisk < 30) return { level: 'Low', message: 'You\'re doing great! Keep it up!', color: 'text-green-600' }
    if (burnoutRisk < 60) return { level: 'Moderate', message: 'Take some breaks today', color: 'text-yellow-600' }
    return { level: 'High', message: 'Please prioritize self-care today', color: 'text-red-600' }
  }

  // Home Dashboard
  const HomeScreen = () => (
    <div className="space-y-4 pb-24 animate-slide-up">
      {/* Header */}
      <div className="flex items-center justify-between px-4 pt-4">
        <div>
          <p className="text-sm text-muted-foreground">Assalam-o-Alaikum</p>
          <h1 className="text-2xl font-bold gradient-text">ScreenShield AI</h1>
        </div>
        <div className="flex items-center gap-2">
          <div className="bg-primary/10 px-3 py-1.5 rounded-full flex items-center gap-1.5">
            <span className="text-lg">🔥</span>
            <span className="text-sm font-semibold text-primary">{streak} days</span>
          </div>
        </div>
      </div>

      {/* Burnout Risk Card */}
      <Card className="mx-4 border-0 shadow-lg overflow-hidden">
        <CardContent className="p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-sm text-muted-foreground">Tomorrow's Burnout Risk</p>
              <h2 className={`text-3xl font-bold ${getBurnoutMessage().color}`}>
                {burnoutRisk}%
              </h2>
            </div>
            <div className="relative w-20 h-20">
              <svg className="w-20 h-20 transform -rotate-90">
                <circle cx="40" cy="40" r="32" fill="none" stroke="#e5e7eb" strokeWidth="8" />
                <circle 
                  cx="40" 
                  cy="40" 
                  r="32" 
                  fill="none" 
                  stroke={burnoutRisk < 30 ? '#22c55e' : burnoutRisk < 60 ? '#eab308' : '#ef4444'}
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={`${2 * Math.PI * 32}`}
                  strokeDashoffset={`${2 * Math.PI * 32 * (1 - burnoutRisk / 100)}`}
                  className="progress-ring-circle"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <AlertTriangle className={`w-6 h-6 ${getBurnoutMessage().color}`} />
              </div>
            </div>
          </div>
          <p className="text-sm text-muted-foreground">{getBurnoutMessage().message}</p>
          <Button 
            className="w-full mt-4 bg-primary hover:bg-primary/90"
            onClick={() => setActiveTab('suggestions')}
          >
            <Sparkles className="w-4 h-4 mr-2" />
            Get Coping Suggestions
          </Button>
        </CardContent>
      </Card>

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-2 gap-3 px-4">
        <Card 
          className="border-0 shadow-md card-hover cursor-pointer"
          onClick={() => setActiveTab('mood')}
        >
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-full bg-pink-100 flex items-center justify-center">
                <Heart className="w-4 h-4 text-pink-500" />
              </div>
              <span className="text-xs text-muted-foreground">Mood</span>
            </div>
            <p className="text-2xl font-bold">
              {dailyData.mood ? moodConfig[dailyData.mood].emoji : '—'}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {dailyData.mood ? moodConfig[dailyData.mood].label : 'Not tracked'}
            </p>
          </CardContent>
        </Card>

        <Card 
          className="border-0 shadow-md card-hover cursor-pointer"
          onClick={() => setActiveTab('screen')}
        >
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                <Smartphone className="w-4 h-4 text-blue-500" />
              </div>
              <span className="text-xs text-muted-foreground">Screen Time</span>
            </div>
            <p className="text-2xl font-bold">{dailyData.screenTime}h</p>
            <p className="text-xs text-muted-foreground mt-1">
              {dailyData.screenTime > 6 ? 'Above average' : 'On track'}
            </p>
          </CardContent>
        </Card>

        <Card 
          className="border-0 shadow-md card-hover cursor-pointer"
          onClick={() => setActiveTab('stress')}
        >
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center">
                <Activity className="w-4 h-4 text-orange-500" />
              </div>
              <span className="text-xs text-muted-foreground">Stress Level</span>
            </div>
            <p className="text-2xl font-bold">{dailyData.stressLevel}/10</p>
            <p className="text-xs text-muted-foreground mt-1">
              {dailyData.stressLevel > 7 ? 'High' : dailyData.stressLevel > 4 ? 'Moderate' : 'Low'}
            </p>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md card-hover">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center">
                <TrendingUp className="w-4 h-4 text-purple-500" />
              </div>
              <span className="text-xs text-muted-foreground">Wellness Score</span>
            </div>
            <p className="text-2xl font-bold">
              {Math.round((dailyData.mood ? 
                { great: 100, good: 80, okay: 50, bad: 30, terrible: 10 }[dailyData.mood] : 50) * 
                (1 - dailyData.screenTime / 20) * 
                (1 - dailyData.stressLevel / 15))}
            </p>
            <p className="text-xs text-muted-foreground mt-1">Keep improving!</p>
          </CardContent>
        </Card>
      </div>

      {/* Daily Tip */}
      <Card className="mx-4 border-0 shadow-md bg-gradient-to-r from-primary/5 to-accent/5">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="font-semibold text-sm">Daily Wellness Tip</p>
              <p className="text-xs text-muted-foreground mt-1">
                "Take breaks between study sessions. Your brain needs rest to retain information better. 
                Try the Pomodoro technique!"
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // Mood Tracking Screen
  const MoodScreen = () => (
    <div className="space-y-4 pb-24 animate-slide-up px-4">
      <div className="pt-4">
        <h2 className="text-2xl font-bold">How are you feeling?</h2>
        <p className="text-muted-foreground">Track your mood to get personalized insights</p>
      </div>

      <Card className="border-0 shadow-lg">
        <CardContent className="p-6">
          <div className="grid grid-cols-5 gap-3">
            {(Object.keys(moodConfig) as Mood[]).map((mood) => (
              <button
                key={mood}
                onClick={() => handleMoodSelect(mood)}
                className={`flex flex-col items-center gap-2 p-3 rounded-xl transition-all ${
                  dailyData.mood === mood 
                    ? 'bg-primary/10 ring-2 ring-primary' 
                    : 'hover:bg-muted'
                }`}
              >
                <span className="text-3xl mood-emoji">{moodConfig[mood].emoji}</span>
                <span className="text-xs font-medium">{moodConfig[mood].label}</span>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {dailyData.mood && (
        <Card className="border-0 shadow-md animate-slide-up">
          <CardHeader>
            <CardTitle className="text-lg">Mood Insights</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-3">
              <div className={`w-12 h-12 rounded-full ${moodConfig[dailyData.mood].color} flex items-center justify-center`}>
                <span className="text-2xl">{moodConfig[dailyData.mood].emoji}</span>
              </div>
              <div>
                <p className="font-semibold">You're feeling {moodConfig[dailyData.mood].label.toLowerCase()}</p>
                <p className="text-sm text-muted-foreground">
                  {dailyData.mood === 'great' && 'Amazing! Keep up the positive energy!'}
                  {dailyData.mood === 'good' && 'Good to hear! What\'s making you happy?'}
                  {dailyData.mood === 'okay' && 'That\'s normal. Small things can improve your day.'}
                  {dailyData.mood === 'bad' && 'Sorry to hear that. Try some coping activities.'}
                  {dailyData.mood === 'terrible' && 'We understand. Please take care of yourself.'}
                </p>
              </div>
            </div>

            <Separator />

            <div>
              <p className="font-medium mb-3">Recommended for you:</p>
              <div className="space-y-2">
                {(dailyData.mood === 'bad' || dailyData.mood === 'terrible' 
                  ? copingSuggestions.highStress 
                  : copingSuggestions.academic
                ).slice(0, 2).map((suggestion, idx) => (
                  <div key={idx} className="flex items-center gap-3 p-3 bg-muted rounded-lg">
                    <suggestion.icon className="w-5 h-5 text-primary" />
                    <div className="flex-1">
                      <p className="font-medium text-sm">{suggestion.title}</p>
                      <p className="text-xs text-muted-foreground">{suggestion.duration}</p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-muted-foreground" />
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="border-0 shadow-md">
        <CardHeader>
          <CardTitle className="text-lg">Weekly Mood History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-end justify-between h-32 gap-2">
            {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, i) => {
              const moods: Mood[] = ['good', 'great', 'okay', 'good', 'bad', 'great', 'good']
              const heights = [70, 90, 50, 75, 30, 85, dailyData.mood ? 
                { great: 90, good: 70, okay: 50, bad: 30, terrible: 15 }[dailyData.mood] : 60]
              return (
                <div key={day} className="flex flex-col items-center gap-2 flex-1">
                  <div 
                    className="w-full bg-primary/20 rounded-t-lg relative overflow-hidden"
                    style={{ height: `${heights[i]}%` }}
                  >
                    <div className="absolute inset-0 bg-gradient-to-t from-primary/40 to-primary/20" />
                  </div>
                  <span className="text-xs text-muted-foreground">{day}</span>
                  <span className="text-lg">{moodConfig[moods[i]].emoji}</span>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // Screen Time Screen
  const ScreenTimeScreen = () => (
    <div className="space-y-4 pb-24 animate-slide-up px-4">
      <div className="pt-4">
        <h2 className="text-2xl font-bold">Screen Time</h2>
        <p className="text-muted-foreground">Monitor and manage your digital usage</p>
      </div>

      <Card className="border-0 shadow-lg">
        <CardContent className="p-6">
          <div className="text-center">
            <p className="text-muted-foreground mb-2">Today's Screen Time</p>
            <div className="flex items-baseline justify-center gap-1">
              <span className="text-5xl font-bold text-primary">{Math.floor(dailyData.screenTime)}</span>
              <span className="text-2xl text-muted-foreground">h</span>
              <span className="text-5xl font-bold text-primary">{Math.round((dailyData.screenTime % 1) * 60)}</span>
              <span className="text-2xl text-muted-foreground">m</span>
            </div>
            <Badge 
              variant={dailyData.screenTime > 6 ? 'destructive' : 'default'}
              className="mt-3"
            >
              {dailyData.screenTime > 6 ? 'Above Recommended' : 'Within Limit'}
            </Badge>
          </div>

          <div className="mt-6">
            <div className="flex justify-between text-sm mb-2">
              <span>Daily Goal: 6 hours</span>
              <span>{Math.round((dailyData.screenTime / 6) * 100)}%</span>
            </div>
            <Progress value={Math.min(100, (dailyData.screenTime / 6) * 100)} className="h-3" />
          </div>
        </CardContent>
      </Card>

      <Card className="border-0 shadow-md">
        <CardHeader>
          <CardTitle className="text-lg">App Usage Breakdown</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {[
            { name: 'Social Media', time: '2h 15m', percent: 50, color: 'bg-pink-500' },
            { name: 'Study/Education', time: '1h 30m', percent: 33, color: 'bg-blue-500' },
            { name: 'Entertainment', time: '45m', percent: 17, color: 'bg-purple-500' }
          ].map((app) => (
            <div key={app.name} className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="font-medium">{app.name}</span>
                <span className="text-muted-foreground">{app.time}</span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div className={`h-full ${app.color} rounded-full`} style={{ width: `${app.percent}%` }} />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="border-0 shadow-md bg-gradient-to-r from-blue-50 to-indigo-50">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Smartphone className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <p className="font-semibold text-sm">Screen Time Tips</p>
              <ul className="text-xs text-muted-foreground mt-2 space-y-1">
                <li>• Use app timers to limit social media</li>
                <li>• Enable grayscale mode after 8 PM</li>
                <li>• Keep phone away during study hours</li>
                <li>• Use Do Not Disturb for focused work</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-3">
        <Button 
          variant="outline" 
          className="flex-1"
          onClick={() => setDailyData(prev => ({ ...prev, screenTime: Math.max(0, prev.screenTime - 0.5) }))}
        >
          -30 min
        </Button>
        <Button 
          className="flex-1 bg-primary"
          onClick={() => setDailyData(prev => ({ ...prev, screenTime: prev.screenTime + 0.5 }))}
        >
          +30 min
        </Button>
      </div>
    </div>
  )

  // Academic Stress Screen
  const StressScreen = () => {
    const stressFactors = [
      'Exams coming up',
      'Too much homework',
      'Family expectations',
      'Peer pressure',
      'Future career worries',
      'Financial concerns'
    ]

    return (
      <div className="space-y-4 pb-24 animate-slide-up px-4">
        <div className="pt-4">
          <h2 className="text-2xl font-bold">Academic Stress</h2>
          <p className="text-muted-foreground">Assess and manage your stress levels</p>
        </div>

        <Card className="border-0 shadow-lg">
          <CardContent className="p-6">
            <p className="text-center text-muted-foreground mb-4">Current Stress Level</p>
            <div className="flex items-center justify-center gap-4">
              <Button 
                variant="outline" 
                size="icon"
                onClick={() => setDailyData(prev => ({ ...prev, stressLevel: Math.max(1, prev.stressLevel - 1) }))}
              >
                -
              </Button>
              <div className="text-center">
                <span className="text-5xl font-bold text-primary">{dailyData.stressLevel}</span>
                <span className="text-xl text-muted-foreground">/10</span>
              </div>
              <Button 
                variant="outline" 
                size="icon"
                onClick={() => setDailyData(prev => ({ ...prev, stressLevel: Math.min(10, prev.stressLevel + 1) }))}
              >
                +
              </Button>
            </div>
            <p className="text-center text-sm mt-4">
              {dailyData.stressLevel <= 3 && <span className="text-green-600">Low stress - Great job managing!</span>}
              {dailyData.stressLevel > 3 && dailyData.stressLevel <= 6 && <span className="text-yellow-600">Moderate - Take breaks when needed</span>}
              {dailyData.stressLevel > 6 && <span className="text-red-600">High - Please prioritize self-care</span>}
            </p>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md">
          <CardHeader>
            <CardTitle className="text-lg">What's causing your stress?</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {stressFactors.map((factor) => (
                <Badge 
                  key={factor} 
                  variant="secondary"
                  className="cursor-pointer hover:bg-primary hover:text-white transition-colors py-2 px-3"
                >
                  {factor}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md">
          <CardHeader>
            <CardTitle className="text-lg">Study-Life Balance</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Study Hours</span>
                <span>6 hours</span>
              </div>
              <Progress value={75} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Sleep</span>
                <span>7 hours</span>
              </div>
              <Progress value={87} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Exercise</span>
                <span>30 min</span>
              </div>
              <Progress value={50} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Social Time</span>
                <span>1 hour</span>
              </div>
              <Progress value={40} className="h-2" />
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Coping Suggestions Screen
  const SuggestionsScreen = () => (
    <div className="space-y-4 pb-24 animate-slide-up px-4">
      <div className="pt-4">
        <h2 className="text-2xl font-bold">AI Coping Suggestions</h2>
        <p className="text-muted-foreground">Personalized recommendations for you</p>
      </div>

      {/* AI Analysis Card */}
      <Card className="border-0 shadow-lg bg-gradient-to-br from-primary/10 to-accent/10">
        <CardContent className="p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="font-semibold">AI Analysis</p>
              <p className="text-xs text-muted-foreground">Based on your data</p>
            </div>
          </div>
          <p className="text-sm">
            {burnoutRisk > 60 
              ? "Your burnout risk is high. Focus on stress reduction activities today."
              : burnoutRisk > 30
              ? "You're doing okay, but take regular breaks to maintain balance."
              : "You're managing well! Keep up your healthy habits."}
          </p>
        </CardContent>
      </Card>

      {/* High Stress Suggestions */}
      {(dailyData.stressLevel > 5 || dailyData.mood === 'bad' || dailyData.mood === 'terrible') && (
        <div className="space-y-3">
          <h3 className="font-semibold flex items-center gap-2">
            <Heart className="w-4 h-4 text-pink-500" />
            Stress Relief
          </h3>
          {copingSuggestions.highStress.map((suggestion, idx) => (
            <Card key={idx} className="border-0 shadow-md card-hover">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <suggestion.icon className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <p className="font-semibold">{suggestion.title}</p>
                      <Badge variant="secondary">{suggestion.duration}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">{suggestion.desc}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Screen Fatigue Suggestions */}
      {dailyData.screenTime > 5 && (
        <div className="space-y-3">
          <h3 className="font-semibold flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-blue-500" />
            Screen Fatigue
          </h3>
          {copingSuggestions.screenFatigue.map((suggestion, idx) => (
            <Card key={idx} className="border-0 shadow-md card-hover">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                    <suggestion.icon className="w-5 h-5 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <p className="font-semibold">{suggestion.title}</p>
                      <Badge variant="secondary">{suggestion.duration}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">{suggestion.desc}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Academic Suggestions */}
      <div className="space-y-3">
        <h3 className="font-semibold flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-purple-500" />
          Academic Success
        </h3>
        {copingSuggestions.academic.map((suggestion, idx) => (
          <Card key={idx} className="border-0 shadow-md card-hover">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center flex-shrink-0">
                  <suggestion.icon className="w-5 h-5 text-purple-600" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <p className="font-semibold">{suggestion.title}</p>
                    <Badge variant="secondary">{suggestion.duration}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">{suggestion.desc}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Emergency Support */}
      <Card className="border-0 shadow-md bg-gradient-to-r from-red-50 to-orange-50">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5" />
            <div>
              <p className="font-semibold text-sm text-red-800">Need Immediate Help?</p>
              <p className="text-xs text-red-700 mt-1">
                If you're feeling overwhelmed, talk to someone you trust or reach out to a counselor. 
                Your mental health matters.
              </p>
              <Button variant="outline" size="sm" className="mt-3 border-red-300 text-red-700 hover:bg-red-100">
                Find Support Resources
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // Bottom Navigation
  const BottomNav = () => (
    <div className="fixed bottom-0 left-0 right-0 z-50">
      <div className="max-w-[480px] mx-auto">
        <div className="glass border-t border-border/50 px-2 pb-safe">
          <div className="flex items-center justify-around py-2">
            {[
              { id: 'home', icon: Home, label: 'Home' },
              { id: 'mood', icon: Heart, label: 'Mood' },
              { id: 'screen', icon: Smartphone, label: 'Screen' },
              { id: 'stress', icon: Activity, label: 'Stress' },
              { id: 'suggestions', icon: Sparkles, label: 'AI Tips' }
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as Tab)}
                className={`flex flex-col items-center gap-1 py-2 px-3 rounded-xl transition-all ${
                  activeTab === item.id 
                    ? 'text-primary bg-primary/10' 
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <item.icon className={`w-5 h-5 ${activeTab === item.id ? 'animate-float' : ''}`} />
                <span className="text-xs font-medium">{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  )

  return (
    <div className="app-container pk-pattern">
      {/* Main Content */}
      <main className="min-h-screen">
        {activeTab === 'home' && <HomeScreen />}
        {activeTab === 'mood' && <MoodScreen />}
        {activeTab === 'screen' && <ScreenTimeScreen />}
        {activeTab === 'stress' && <StressScreen />}
        {activeTab === 'suggestions' && <SuggestionsScreen />}
      </main>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}

export default App
